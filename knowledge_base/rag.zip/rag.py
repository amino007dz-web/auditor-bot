"""
RAG Context Builder — injects relevant past vulnerabilities into AI prompts.
"""
import logging
import re
from typing import Dict, List, Optional

from knowledge_base.db import KnowledgeBase

logger = logging.getLogger(__name__)

CONTRACT_TYPE_KEYWORDS: Dict[str, List[str]] = {
    "ERC20":        ["ERC20", "IERC20", "transfer", "approve", "allowance", "totalSupply", "balanceOf"],
    "ERC721":       ["ERC721", "IERC721", "safeTransferFrom", "mint", "tokenURI", "ownerOf"],
    "ERC1155":      ["ERC1155", "IERC1155", "safeTransferFrom", "uri"],
    "Lending":      ["lend", "borrow", "collateral", "liquidate", "interestRate", "loan"],
    "DEX/AMM":      ["swap", "pool", "liquidity", "addLiquidity", "removeLiquidity", "reserve"],
    "Bridge":       ["bridge", "relay", "crossChain", "message", "validator", "consensus"],
    "Staking":      ["stake", "unstake", "reward", "withdrawStake", "delegate"],
    "Governance":   ["propose", "vote", "quorum", "governor", "timelock"],
    "Vault":        ["vault", "deposit", "withdraw", "share", "strategy", "harvest"],
    "Oracle":       ["oracle", "priceFeed", "getPrice", "aggregator", "roundData"],
    "Multisig":     ["multisig", "signature", "confirm", "execute", "threshold"],
    "Proxy":        ["proxy", "delegatecall", "implementation", "upgradeTo", "UUPS"],
}


def detect_contract_type(code: str) -> str:
    code_lower = code.lower()
    scores = {}
    for ctype, keywords in CONTRACT_TYPE_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw.lower() in code_lower)
        if score > 0:
            scores[ctype] = score
    if not scores:
        return "General"
    return max(scores, key=scores.get)


def extract_key_functions(code: str) -> List[str]:
    funcs = re.findall(r'function\s+(\w+)\s*\(', code)
    return funcs[:15]


class RAGContext:
    """Builds relevant context from the Knowledge Base for a given code snippet."""

    def __init__(self, kb: KnowledgeBase, max_context_chars: int = 2000):
        self.kb = kb
        self.max_context_chars = max_context_chars

    def build_context(self, code: str, protocol_name: str = "") -> str:
        contract_type = detect_contract_type(code)
        funcs = extract_key_functions(code)
        patterns = self.kb.find_similar_patterns(code[:200], contract_type, limit=5)
        if not patterns:
            return ""
        parts: List[str] = []
        parts.append(f"## أنماط ثغرات سابقة مشابهة (نوع العقد: {contract_type})")
        parts.append("")
        for p in patterns:
            if len("\n".join(parts)) > self.max_context_chars:
                break
            line = f"- **{p.get('name', '?')}** [{p.get('severity', '?')}] — {p.get('description', '')[:200]}"
            if p.get('fix_code'):
                line += f"\n  - الإصلاح السابق: `{p['fix_code'][:150]}`"
            parts.append(line)
            self.kb.increment_hit(p['id'])
        parts.append("")
        return "\n".join(parts)
